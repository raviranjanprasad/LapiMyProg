#include<stdio.h>
#include<conio.h>
FILE *fs,*ft;
void main()
{
 int c,d;
 clrscr();
 if(fs=fopen("COMMENT.TXT","r"
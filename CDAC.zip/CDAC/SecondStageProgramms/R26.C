	    /*PROGRAM FOR QUARDATIC EQUATION*/
#include<stdio.h>
#include<canio.h>
#include<math.h>
void main()
{


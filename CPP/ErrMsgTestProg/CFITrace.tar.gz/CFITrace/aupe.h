#ifndef _AUPE_H
#define _AUPE_H
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
#include<unistd.h>
#include<error.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/ioctl.h>
#include<sys/wait.h>
#include<string.h>
#include<malloc.h>
#include <time.h>
#include <stdarg.h>     /* va_list, va_start, va_arg, va_end */

#define oflag O_CREAT|O_RDWR|O_TRUNC
#define mode 0666

#endif

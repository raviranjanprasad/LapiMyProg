
#ifndef __RAND_API_H
#define __RAND_API_H

extern void initRand( void );

extern float getSRand( void );

extern int getRand( int max );

extern void findAvg(void );

#endif /* __RAND_API_H */
			 
